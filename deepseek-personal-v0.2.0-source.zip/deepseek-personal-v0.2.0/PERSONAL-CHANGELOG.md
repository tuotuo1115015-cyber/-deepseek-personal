# DeepSeek Personal v0.2.0

基于 DeepSeek Chat Demo v0.1.3。

## 本次仅修改
- `src/components/chatInput/ChatInput.tsx`
  - 在原有输入框功能栏中增加模型选择器。
  - 仅在输入框获得焦点时显示；焦点离开输入区域后收起。
  - 每个会话单独记住模型选择，保存在浏览器 localStorage。
  - 使用项目原有 Select 组件，不新增或重做原版 UI 组件。
- `src/services/chat/store.ts`
  - 发送新消息时使用当前选择的模型。
  - 原有续写、重新生成、编辑消息流程保持默认行为。

## 模型
- `deepseek-flash`（V4.1 Flash）
- `deepseek-v4-pro`（V4 Pro）

## 说明
此包是源码包，不是可直接双击运行的网页构建产物。当前执行环境无法连接 npm registry，因此尚未完成依赖安装、TypeScript 检查和生产构建。请勿将其视为已通过运行验证的发布版。
